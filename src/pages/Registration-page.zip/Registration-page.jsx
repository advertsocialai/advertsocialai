import React, { useState } from "react";
import Swal from "sweetalert2";

export default function RegistrationPage() {
  const [form, setForm] = useState({
    fullName: "",
    companyName: "",
    email: "",
    phone: "",
    country: "",
    password: "",
    confirmPassword: "",
    acceptTerms: false,
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const isValidEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));

    // ✅ clear error on typing
    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = {};

    if (!form.fullName.trim()) newErrors.fullName = "Name is required.";
    if (!form.companyName.trim()) newErrors.companyName = "Company name is required.";

    if (!form.email.trim()) newErrors.email = "Email is required.";
    else if (!isValidEmail(form.email))
      newErrors.email = "Enter a valid email address.";

    if (!form.phone.trim()) newErrors.phone = "Phone number is required.";
    if (!form.country.trim()) newErrors.country = "Country is required.";

    if (!form.password) newErrors.password = "Password is required.";
    else if (form.password.length < 6)
      newErrors.password = "Minimum 6 characters.";

    if (!form.confirmPassword)
      newErrors.confirmPassword = "Confirm password is required.";
    else if (form.password !== form.confirmPassword)
      newErrors.confirmPassword = "Passwords do not match.";

    if (!form.acceptTerms)
      newErrors.terms = "You must accept the terms & conditions.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
        setLoading(true);

        const payload = {
            company_name: form.companyName,
            full_name: form.fullName,
            email: form.email,
            phone: form.phone,
            password: form.password,
            password_confirmation: form.confirmPassword,
            country: form.country,
            terms: form.acceptTerms,
        };

        try {
            const response = await fetch(
                "https://bohrx.ai/backendadmin/api/register",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                }
            );

            const data = await response.json();

            if (response.ok && data?.status === true) {
                Swal.fire("Success", "Account created successfully", "success");
                setForm({
                    fullName: "",
                    companyName: "",
                    email: "",
                    phone: "",
                    country: "",
                    password: "",
                    confirmPassword: "",
                    acceptTerms: false,
                });
            } else {
                Swal.fire("Error", data?.message || "Registration failed", "error");
            }
        } catch {
            Swal.fire("Error", "Server error. Please try again later.", "error");
        } finally {
            setLoading(false);
        }
    };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{
        backgroundImage: "url(/assets/images/registration-bg.png)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div
        className="w-full max-w-md rounded-2xl shadow-2xl px-6 py-8 sm:px-6 sm:py-10 flex flex-col items-center"
        style={{
          backgroundColor: "rgba(255,255,255,0.75)",
          backdropFilter: "blur(6px)",
        }}
      >
        <h2 className="text-2xl font-bold text-center">
          Create your account
        </h2>
        <p className="mb-5 text-center text-sm text-gray-600">
          Join Advert Social AI and get started today.
        </p>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3">

          {[
            { name: "fullName", placeholder: "Your Name" },
            { name: "companyName", placeholder: "Company Name" },
            { name: "email", placeholder: "Email Address" },
            { name: "phone", placeholder: "Phone Number" },
            { name: "country", placeholder: "Country" },
          ].map((field) => (
            <div key={field.name} className="w-full">
              <input
                name={field.name}
                value={form[field.name]}
                onChange={handleChange}
                placeholder={errors[field.name] || field.placeholder}
                className={`p-3 w-full rounded-xl border ${
                  errors[field.name]
                    ? "border-red-500 placeholder-red-500 placeholder:text-xs"
                    : "border-gray-200 placeholder-gray-500"
                } focus:outline-none focus:ring-2 focus:ring-black bg-[rgba(255,255,255,0.6)]
                font-semibold text-base`}
              />
            </div>
          ))}

          <div className="relative w-full">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder={errors.password || "Password"}
              className={`p-3 w-full rounded-xl border ${
                errors.password
                  ? "border-red-500 placeholder-red-500 placeholder:text-xs"
                  : "border-gray-200 placeholder-gray-500"
              } focus:outline-none focus:ring-2 focus:ring-black bg-[rgba(255,255,255,0.6)]
              font-semibold text-base`}
            />
            <img
              src={
                showPassword
                  ? "/assets/images/eye-open.png"
                  : "/assets/images/eye-closed.png"
              }
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 cursor-pointer"
            />
            {errors.password && (
              <p className="text-xs text-red-500 mt-1">{errors.password}</p>
            )}
          </div>

        
          <div className="relative w-full">
            <input
              type={showConfirmPassword ? "text" : "password"}
              name="confirmPassword"
              value={form.confirmPassword}
              onChange={handleChange}
              placeholder={errors.confirmPassword || "Confirm Password"}
              className={`p-3 w-full rounded-xl border ${
                errors.confirmPassword
                  ? "border-red-500 placeholder-red-500 placeholder:text-xs"
                  : "border-gray-200 placeholder-gray-500"
              } focus:outline-none focus:ring-2 focus:ring-black bg-[rgba(255,255,255,0.6)]
              font-semibold text-base`}
            />
            <img
              src={
                showConfirmPassword
                  ? "/assets/images/eye-open.png"
                  : "/assets/images/eye-closed.png"
              }
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 cursor-pointer"
            />
            {errors.confirmPassword && (
              <p className="text-xs text-red-500 mt-1">{errors.confirmPassword}</p>
            )}
          </div>

         
          <label className="flex items-center gap-2 text-sm mt-1">
            <input
              type="checkbox"
              name="acceptTerms"
              checked={form.acceptTerms}
              onChange={handleChange}
            />
            <span>I agree to the Terms & Conditions</span>
          </label>

          {errors.terms && (
            <p className="text-xs text-red-500">{errors.terms}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="mt-2 w-full py-3 bg-black text-white rounded-full font-semibold"
          >
            {loading ? "Creating Account..." : "Create Account"}
          </button>

        </form>
      </div>
    </div>
  );
}
